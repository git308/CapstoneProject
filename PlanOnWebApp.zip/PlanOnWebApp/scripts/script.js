//JavaScript to load the calender and retrieve the events.
//Author: Abigail Suarez
//Date: 5/10/2023

let calnav = 0;
let clicked = null;
let events = localStorage.getItem('events') ? JSON.parse(localStorage.getItem('events')) : [];

let dayPointer = new Date();
const bttntext = document.getElementById('weekViewbttn');
const week = document.getElementById('wheader');
const calendar = document.getElementById('calendar');
const weekdays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

/**
 * Function to change between the monthly view and the weekly view of the calendar.
 * Executes when user clicks "Month"/"Week" button.
 */
function viewChange() {
    var calelem = document.getElementById('calendar');
    var cwelem = document.getElementById('calWeekDiv');
    var wekelem = document.getElementById('weeklyView');
    var bttntext = document.getElementById('weekViewbttn');
    var nextBttn = document.getElementById('nextButton');
    var backBttn = document.getElementById('backButton');
    if(bttntext.innerText == 'Week') {
      loadWeek();
      calelem.style.display = 'none';
      cwelem.style.display = 'none';
      wekelem.style.display = 'grid';
      bttntext.innerText = 'Month';
      nextBttn.style.display = 'none';
      backBttn.style.display = 'none';
    }
    else {
      calelem.style.display = 'flex';
      cwelem.style.display = '';
      wekelem.style.display = 'none';
      bttntext.innerText = 'Week';
      nextBttn.style.display = '';
      backBttn.style.display = '';
    }
  }

/**
 * Function to load the monthly view of the calendar.
 * Retrieves the events for each day from the localStorage.
 * Executed on the first load and every reload.
 */
function loadCal() {
    const dt = new Date();

    if (calnav !== 0) {
        dt.setDate(1);
        dt.setMonth(new Date().getMonth() + calnav);
    }

    const day = dt.getDate();
    const month = dt.getMonth();
    const year = dt.getFullYear();

    const firstDayOfMonth = new Date(year, month, 1);
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const dateString = firstDayOfMonth.toLocaleDateString('en-us', {
        weekday: 'long',
        year: 'numeric',
        month: 'numeric',
        day: 'numeric',
    });
    const paddingDays = weekdays.indexOf(dateString.split(',')[0]);
    
    document.getElementById('monthDisplay').innerText = `${dt.toLocaleDateString('en-us', {month: 'long'})} ${year}`;

    calendar.innerHTML = '';

    for(let i = 1; i<= paddingDays + daysInMonth; i++) {
        const daySquare = document.createElement('div');
        daySquare.classList.add('day');

        const dayString = `${year}-` + '0'+`${month + 1}-${i - paddingDays}`;
        const mString = `${month + 1}`;
        const dString = `${i - paddingDays}`;
        const yString = `${year}`;
        if(i > paddingDays) {
            daySquare.innerText = i - paddingDays;
            
            const eventForDay = events.find(e => e.date === dayString);

            if(i - paddingDays === day && calnav === 0) {
                daySquare.id = 'currentDay';
            }

            if(eventForDay) {
                const eventDiv = document.createElement('div');
                eventDiv.classList.add('event');
                eventDiv.innerText = eventForDay.title;
                daySquare.appendChild(eventDiv);
            }

            daySquare.addEventListener('click', (e) => {
                prevSelDay = document.getElementById('selectedDay');
                if(prevSelDay) {
                    prevSelDay.id = '';
                }
                daySquare.id = 'selectedDay';
                dayPointer = new Date(yString, month, dString);
            });
        } else {
            daySquare.classList.add('padding');
        }

        calendar.appendChild(daySquare);
    }
}
/**
 * Function to load the weekly view of the calendar.
 * Executes when the user clicks the "Week" button
 */
function loadWeek() {
    const dt = dayPointer;
    const dateNums = [];
    const month = dt.getMonth();
    const year = dt.getFullYear();

    const lstdayprevmonth = new Date(year, month, 0).getDate();
    const daysInMonth = new Date(year, month + 1, 0).getDate();    
    
    const dayNum = dt.getDay();
    const dateNum = dt.getDate();

    let firstdayofweek = dateNum - dayNum;
    let paddingDays = 0;
    
    week.removeChild(week.lastElementChild);

    //In current month
    if(firstdayofweek >= 1 & firstdayofweek <= daysInMonth - 6){
        for(var i=firstdayofweek; i<firstdayofweek+7; i++){
            dateNums.push(i);
        }
    }
    //In previous month
    else if(firstdayofweek < 1) {
        paddingDays = firstdayofweek * -1;
        if(paddingDays < 7){
            
            for(var i=lstdayprevmonth - paddingDays; i<=lstdayprevmonth; i++) {
                dateNums.push(i);
            }
            for(var i=1; i<(7-paddingDays); i++) {
                dateNums.push(i);
            }
        }
        else if(paddingDays >= 7){
    
            for(var i=lstdayprevmonth - paddingDays; i<lstdayprevmonth - paddingDays + 7; i++) {
                dateNums.push(i);
            }
        }
        firstdayofweek = lstdayprevmonth - paddingDays;
    }
    //In next month
    else if(firstdayofweek > daysInMonth - 6) {
        paddingDays = 7-((daysInMonth + 1) - firstdayofweek);
        
        if(paddingDays < 7){
            for(var i = firstdayofweek; i<=daysInMonth; i++){
                dateNums.push(i);
            } 
            for(var i=1; i<=paddingDays; i++) {
                dateNums.push(i);
            }
        }
        else if(paddingDays >= 7){
            for(var i=paddingDays-7; i<paddingDays; i++){
                dateNums.push(i);
            }
        }
    }

    document.getElementById('monthDisplay').innerText = `${dt.toLocaleDateString('en-us', {month: 'long'})} ${year}`;

    const weekNumsList = document.createElement('ul');
    weekNumsList.classList.add('dayNumbers');

    const day1 = document.createElement('li');
    day1.innerText = String(dateNums[0]);
    const day2 = document.createElement('li');
    day2.innerText = String(dateNums[1]);
    const day3 = document.createElement('li');
    day3.innerText = String(dateNums[2]);
    const day4 = document.createElement('li');
    day4.innerText = String(dateNums[3]);
    const day5 = document.createElement('li');
    day5.innerText = String(dateNums[4]);
    const day6 = document.createElement('li');
    day6.innerText = String(dateNums[5]);
    const day7 = document.createElement('li');
    day7.innerText = String(dateNums[6]);

    weekNumsList.append(day1,day2, day3, day4, day5, day6, day7);    
    week.appendChild(weekNumsList);
    
}

/**
 * Funtion to open the add event modal.
 * Executes when user clicks the plus sign button.
 */
function addEvent() {
    const inputdiv = document.getElementById('addEvent');
    const inputForm = document.createElement('form');
    inputForm.id = "eform";        
    
    const eventNameDiv = document.createElement('div');
    eventNameDiv.classList.add('mb-3');
        
    const eventDtDiv = document.createElement('div');
    eventDtDiv.classList.add('mb-3');
    
    const eventTimeDiv =  document.createElement('div');
    eventTimeDiv.classList.add('mb-3');

    const eventNameLabel = document.createElement('label');
    eventNameLabel.classList.add("form-label");
    eventNameLabel.for = "eventName";
    eventNameLabel.innerText = "Event Name";

    const eventNameInput = document.createElement('input');
    eventNameInput.type = "text";
    eventNameInput.classList.add('form-control');
    eventNameInput.id = "eventName";

    const eventDtLabel = document.createElement('label');
    eventDtLabel.classList.add("form-label");
    eventDtLabel.for = "eventDt";
    eventDtLabel.innerText = "Event Date";

    const eventDtInput = document.createElement('input');
    eventDtInput.type = "date";
    eventDtInput.classList.add('form-control');
    eventDtInput.id = "eventDt";

    const timeRowDiv = document.createElement('div');
    timeRowDiv.classList.add('row')

    const strtDiv = document.createElement('div');
    const strtLabel = document.createElement('label');
    strtLabel.classList.add("form-label");
    strtLabel.for = "strtTime";
    strtLabel.innerText = "Start Time";

    const strtTimeInput = document.createElement('input');
    strtTimeInput.classList.add('form-control');
    strtTimeInput.type = 'time';
    strtTimeInput.id = 'strtTime';

    const endDiv = document.createElement('div');
    const endLabel = document.createElement('label');
    endLabel.classList.add("form-label");
    endLabel.for = "endTime";
    endLabel.innerText = "End Time"; 

    const endTimeInput = document.createElement('input');
    endTimeInput.classList.add('form-control');
    endTimeInput.type = 'time';
    endTimeInput.id = 'endTime';    

    strtDiv.append(strtLabel, strtTimeInput);
    endDiv.append(endLabel, endTimeInput);

    timeRowDiv.append(strtDiv, endDiv);

    eventNameDiv.append(eventNameLabel, eventNameInput);
    eventDtDiv.append(eventDtLabel, eventDtInput);

    inputForm.append(eventNameDiv, eventDtDiv, timeRowDiv);
    inputdiv.append(inputForm);
}

/**
 * Function to save the event created in the add event modal.
 * Updates localStorage accordingly.
 */
function saveEvent() {
    const efrm = document.getElementById("eform");
    const eventName = document.getElementById("eventName").value;
    const eventDt = document.getElementById("eventDt").value;
    const eStartTime = document.getElementById('strtTime').value;
    const eEndTime = document.getElementById('endTime').value;

    events.push({
        date: eventDt,
        title: eventName,
        startTime: eStartTime,
        endTime: eEndTime
    });

    localStorage.setItem('events', JSON.stringify(events));
    efrm.reset();
    closeModal();

    console.log(JSON.parse(localStorage.getItem('events')));
}

/**
 * Function to close and clear the add event modal
 */
function closeModal() {
    const formMdl = document.getElementById("eform");
    formMdl.remove();
}

/**
 * Functino to delete an event from the localStorage.
 */
function deleteEvent() {
    events = events.filter(e => e.date !== clicked);
    localStorage.setItem('events', JSON.stringify(events));
    closeModal();
}

/**
 * Function to initiate the next and back buttons to move forward or backward
 * in the monthly view of the calendar.
 */
function initButtons() {
    document.getElementById('nextButton').addEventListener('click', () => {
        if(bttntext.innerText == 'Week') {
            calnav++;
            loadCal();
        }
        else {
            loadWeek();
        }
    });
    document.getElementById('backButton').addEventListener('click', () => {
        if(bttntext.innerText == 'Week') {
            calnav--;
            loadCal();
        }
        else {
            loadWeek();
        }
        
    });
    document.getElementById('eventButton').addEventListener('click', addEvent);
    
}

//Initiate buttons and load monthly view of calendar.
initButtons();
loadCal();

